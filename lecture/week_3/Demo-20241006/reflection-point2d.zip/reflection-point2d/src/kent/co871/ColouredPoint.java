package kent.co871;

import java.awt.*;

public class ColouredPoint extends Point2D {
    private final Color colour;
    public ColouredPoint(int x, int y, Color colour) {
        super(x, y);
        this.colour = colour;
    }
    public Color getColour() {
        return colour;
    }
    public String toString() {
        return super.toString() + ", colour: " + colour;
    }
}

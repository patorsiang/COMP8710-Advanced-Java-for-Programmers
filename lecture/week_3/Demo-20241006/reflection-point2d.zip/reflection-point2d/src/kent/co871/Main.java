package kent.co871;

import java.awt.*;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class Main {
    public static void main(String[] args) throws CloneNotSupportedException {

        Point2D pt1 = new ColouredPoint(1, 5, Color.RED);
        ColouredPoint pt2 = (ColouredPoint) pt1.moveX(2);
        System.out.println("pt2: " + pt2);

// get dynamic type
        Class clazz = pt1.getClass();
        System.out.println("pt1 dynamic type: " + clazz);

// get all fields declared in the class
        Field[] fields = clazz.getDeclaredFields();
        for (Field f : fields) {
            System.out.println(f);
        }

        // get all public methods (incl. inherited)
        Method[] methods = clazz.getMethods();
        for (var m : methods) {
            printMethodSignature(m);
        }

        // Reflection: invoke a method
        try {
            // method without parameter
            var getX = clazz.getMethod("getX");
            var x = (int) getX.invoke(pt1);
            System.out.println("pt1 x=" + x);

            // method with parameter
            var moveX = clazz.getMethod("moveX", int.class);
            var pt3 = (ColouredPoint) moveX.invoke(pt1, 3);
            System.out.println("pt3 x=" + getX.invoke(pt3));
        } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
            e.printStackTrace();
        }

    }

    private static void printMethodSignature(Method m) {

        System.out.print(m.getReturnType().getName() + " ");
        System.out.print(m.getName());

        Class[] params = m.getParameterTypes();
        System.out.print("(");
        for (Class p : params)
            System.out.print(p.getName() + " ");    // print parameter type
        System.out.println(")");
    }
}

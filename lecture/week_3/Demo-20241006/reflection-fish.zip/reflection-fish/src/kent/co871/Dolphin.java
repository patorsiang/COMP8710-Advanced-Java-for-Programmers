package kent.co871;

public class Dolphin extends Fish {
}

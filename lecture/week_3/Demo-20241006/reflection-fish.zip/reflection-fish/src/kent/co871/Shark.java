package kent.co871;

public class Shark extends Fish{
}

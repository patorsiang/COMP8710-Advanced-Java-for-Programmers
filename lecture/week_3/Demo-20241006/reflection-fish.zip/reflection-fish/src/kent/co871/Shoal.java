package kent.co871;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

public class Shoal {
    private final List<Fish> fishList = new ArrayList<>();

    public void add(Fish f) {
        fishList.add(f);
    }

    public int getSize() {
        return fishList.size();
    }

    public void grow() {
        try {
            var fish = createNewFish(fishList.getFirst());
            add(fish);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            ;
        }
    }

    private Fish createNewFish(Fish fish) throws NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
        return fish.getClass()
                   .getDeclaredConstructor()
                   .newInstance();
    }

    public Object factory(String className) throws
            ClassNotFoundException, NoSuchMethodException,
            IllegalAccessException, InstantiationException,
            InvocationTargetException
    {
        return Class.forName(className).getDeclaredConstructor().newInstance();
    }


}

package kent.co871;

import java.lang.reflect.InvocationTargetException;

public class Main {
    public static void main(String[] args) {
        Shoal sharks = new Shoal();
        sharks.add(new Shark());
        sharks.grow();     // Grow with more Shark objects
        System.out.println(sharks.getSize());

        Shoal dolphins = new Shoal();
        dolphins.add(new Dolphin());
        for (int i = 0; i < 5; i++)
            dolphins.grow();
        System.out.println(dolphins.getSize());

        Shark basking = null;
        try {
            var shoal = new Shoal();
            var shark = (Shark) shoal.factory("kent.co871.Shark");
            var dolphin = (Dolphin) shoal.factory("kent.co871.Dolphin");
            shoal.add(shark);
            shoal.add(dolphin);
            System.out.println(shoal.getSize());
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } catch (NoSuchMethodException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (InstantiationException e) {
            throw new RuntimeException(e);
        } catch (InvocationTargetException e) {
            throw new RuntimeException(e);
        }


    }
}

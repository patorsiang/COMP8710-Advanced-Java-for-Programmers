package kent.co871;

public class Cat extends Pet {

    public Cat(String name) {
        super(name);
    }

    @Override
    public String getAction() {
        return "meowing";
    }
}

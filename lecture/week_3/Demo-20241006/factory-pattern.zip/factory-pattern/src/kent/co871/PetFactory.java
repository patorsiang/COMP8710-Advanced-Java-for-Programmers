package kent.co871;

public class PetFactory {
    public static Pet createPet(PetType type, String name) {
        switch (type) {
            case DOG:
                return new Dog(name);
            case CAT:
                return new Cat(name);
        }
        throw new IllegalArgumentException("Invalid pet type");
    }
}

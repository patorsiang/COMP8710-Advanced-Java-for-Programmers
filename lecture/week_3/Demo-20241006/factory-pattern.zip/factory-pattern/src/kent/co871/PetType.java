package kent.co871;

public enum PetType {
    DOG, CAT
}

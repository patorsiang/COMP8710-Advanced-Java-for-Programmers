package kent.co871;

public class Main {
    public static void main(String[] args) {

var dog = PetFactory.createPet(PetType.DOG, "Spot");
System.out.println(dog);

var cat = PetFactory.createPet(PetType.CAT, "Molly");
System.out.println(cat);

    }
}

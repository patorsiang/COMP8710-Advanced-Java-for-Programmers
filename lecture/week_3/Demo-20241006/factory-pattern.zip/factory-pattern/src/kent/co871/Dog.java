package kent.co871;

public class Dog extends Pet {

    public Dog(String name) {
       super(name);
    }

    @Override
    public String getAction() {
        return "barking";
    }
}

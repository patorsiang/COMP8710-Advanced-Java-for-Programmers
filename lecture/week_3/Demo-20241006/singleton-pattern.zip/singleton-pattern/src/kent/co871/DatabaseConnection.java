package kent.co871;

public class DatabaseConnection {

    private static DatabaseConnection db;

    private DatabaseConnection() {
        System.out.println("Create connection to database.");
    }

    public static DatabaseConnection getDBConnection() {
        if (db == null) {
            db = new DatabaseConnection();
        }
        return db;
    }
}

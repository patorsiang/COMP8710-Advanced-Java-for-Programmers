package kent.co871;

public class Main {

    public static void main(String[] args) {
        var db1 = DatabaseConnection.getDBConnection();
        var db2 = DatabaseConnection.getDBConnection();
        System.out.println(db1 == db2);
    }
}

package kent.co871;

public interface Pizza {
    void decorate();
}

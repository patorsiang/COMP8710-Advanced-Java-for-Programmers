package com.example.demo;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextInputDialog;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;

import java.io.File;
import java.util.Optional;

public class Controller {
    @FXML
    private Label lblResult;

    @FXML
    private void useDialog() {
        var dialog = new TextInputDialog();
        dialog.setTitle("Dialog");
        dialog.setHeaderText("Enter some text.");
        Optional<String> result = dialog.showAndWait();
        result.ifPresent(text -> lblResult.setText(text + "\n"));
    }

    @FXML
    private void selectFile() {
        var myChooser = new FileChooser();
        ExtensionFilter extFilter = new ExtensionFilter("Text Files", "*.java");
        myChooser.getExtensionFilters().add(extFilter);

        File sourceFile = myChooser.showOpenDialog(new Stage());
        if (sourceFile == null) return;
        lblResult.setText(sourceFile.getName());

    }
}
